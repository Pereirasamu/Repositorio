﻿namespace Classic_Snakes_Game
{
    internal static class Settings
    {
        public static int Width { get; set; } = 16;
        public static int Height { get; set; } = 16;
        public static string Directions { get; set; } = "left";
    }
}